//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.servlet.*;
//import javax.servlet.http.*;
//import javax.servlet.annotation.*;
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import Utils.JDBCUtils;
//import java.sql.SQLException;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//
//@WebServlet(name = "LoginServlet", value = "/Login")
//public class LoginServlet extends HttpServlet {
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;");
//        PrintWriter out= response.getWriter();
//        String username=request.getParameter("username");
//        String password=request.getParameter("password");
// 
//        String sql="select * from  users where name=? and password=?";
//        ResultSet rs = new JDBCUtils().executeQuery(sql,username,password);
//        
//        try {
//            if (rs.getRow() > 0){
//                out.print("LoginSuccess！");
//            }else {
//                out.print("Error！");
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
//        }
// 
//    }
// 
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        doGet(request, response);
//    }
//}