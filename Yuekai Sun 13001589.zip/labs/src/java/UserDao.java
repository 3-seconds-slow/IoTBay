package dao;
 
import Utils.JDBCUtils;
import entity.User;
 
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class UserDao extends JDBCUtils {
    public User login(User user){
        String sql="select * from  users where \"name\" = '" + user.getName() + "' and \"password\"= '" + user.getPassword() + "'";
        ResultSet rs = super.executeQuery(sql);
        User user1=null;
        try {
            while (rs.next()){
                user1=new User();
                user1.setName(rs.getString("name"));
                user1.setPassword(rs.getString("password"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return user1;
    }
    public int insertUser(User user) throws SQLException
    {
        String sql;
        sql="insert into USERS(\"email\",\"name\",\"password\",\"gender\",\"phonenum\",\"favoritecolor\")values('" + user.getEmail() + "','" + user.getName() + "','" + user.getPassword() + "','" + user.getGender()+ "','" + user.getPhonenum()+ "','" + user.getFavoritecolor() + "')";
        int rs = super.executeUpdate(sql);
        return 1;   
      }
    
    
    public boolean updateUser(User user)throws SQLException
    {
        String sql;
        sql="update users set \"name\"='" + user.getName() + "',\"gender\"='" + user.getGender()+ "',\"phonenum\"='" + user.getPhonenum()+ "',\"favoritecolor\"='" + user.getFavoritecolor()+ "' where \"email\"='" + user.getEmail() + "'";
        int rs = super.executeUpdate(sql);
        return true;
    }        

    public int deleteById(String Email)throws SQLException
    {
       String sql;
       sql="delete from users where  \"email\"= '" + Email + "'";
       int rs = super.executeUpdate(sql);
       return 1;
    }
    
   public User searchByEmail(String Email) throws SQLException
   {
       String sql;
       sql="select * from users where  \"email\"= '" + Email + "'";
       ResultSet rs = super.executeQuery(sql);
       User S = new User();
       if(rs.next())
       {
                S.setEmail(rs.getString(1));
                S.setName(rs.getString(2));
                S.setPassword(rs.getString(3));
                S.setGender(rs.getString(4));
                S.setPhonenum(rs.getString(5));
                S.setFavoritecolor(rs.getString(6));
       }
       else
       {
           S=null;
       }    
       
      return S;   
   }
    public List<User> searchAll()throws SQLException
    {
       String sql;
       sql="select * from users";
       List<User>mylist=new ArrayList<User>();
       ResultSet rs = super.executeQuery(sql);
       while(rs.next())
       {
                User S=new User();
                S.setEmail(rs.getString(1));
                S.setName(rs.getString(2));
                S.setPassword(rs.getString(3));
                S.setGender(rs.getString(4));
                S.setPhonenum(rs.getString(5));
                S.setFavoritecolor(rs.getString(6));
                mylist.add(S);
                S=null;
       }    
       return mylist;
    }
}

