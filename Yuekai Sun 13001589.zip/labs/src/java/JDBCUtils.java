package Utils;

import java.sql.*;

public class JDBCUtils {
    public Connection getConnection(){
        String url="jdbc:derby://localhost:1527/usersdb";
        String username="isduser";
        String password="admin";
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection conn= DriverManager.getConnection(url,username,password);
            return conn;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
 
    public ResultSet executeQuery(String sql,Object...params){
        Connection conn=this.getConnection();
        try {
            
            PreparedStatement pamt=conn.prepareStatement(sql);
            if (params!=null && params.length!=0){
                for (int i=0;i<params.length;i++){
                    pamt.setObject(i+1,params[i]);
                }
            }
            System.out.print(pamt);
            ResultSet rs=pamt.executeQuery();
            return rs;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }
 
    public int executeUpdate(String sql,Object...params){
        Connection conn=this.getConnection();
        try {
            PreparedStatement pamt=conn.prepareStatement(sql);
            if (params!=null && params.length!=0){
                for (int i=0;i<params.length;i++){
                    pamt.setObject(i+1,params[i]);
                }
            }
            int result=pamt.executeUpdate();
            return result;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return 0;
    }
    
    public int executeDelete(String sql,Object...params){
        Connection conn=this.getConnection();
        try {
            PreparedStatement pamt=conn.prepareStatement(sql);
            if (params!=null && params.length!=0){
                for (int i=0;i<params.length;i++){
                    pamt.setObject(i+1,params[i]);
                }
            }
            int result=pamt.executeUpdate();
            return result;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return 0;
    }
    
    public void close(ResultSet rs){
        try {
            rs.getStatement().getConnection().close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}